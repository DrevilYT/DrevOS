# CMDAdminScript
A script that switches you from a normal Command Prompt to an elevated Command Prompt.
