# DrevNET
- A game launcher designed for you. Powered by Steam. Made by Drevil. I had to port the original version to support the Github size limit lol. Note, this launcher is not fully open source, but rather partially open source due to Electron coding restrictions.

# NOTE:
- DrevNET has officially been discontinued. It will still be usable and receive updates, however there will be no new events, sales or any new games. We will only push out bug fixes and patches. DrevNET is no longer our main focus.
- DrevNET will officially shutdown on 21st of March, 2024. All servers will be closed. Drev+ members will receive a full refund for the month (if they haven't already cancelled). All download servers (Github and Drev) will be shutdown aswell. Say goodbye.

# TUTORIAL:

# METHOD 1: Github Server
- LINK: https://github.com/lolDrev/DrevNET/archive/refs/heads/main.zip
- Step 1: Download the code from the main branch and extract it. (or the link is provided above)
- Step 2: Go to releases and download the latest DrevNET.exe file.
- Step 3: Put the DrevNET.exe file in the extracted folder of the main branch.
- Step 4: Finally, you can open DrevNET_startup_routine.exe to Launch DrevNET.
- Optional Step: You can make a shortcut of the DrevNET_startup_routine.exe file and move it to the desktop or wherever you like for easier access.

# METHOD 2: Drev's Server (Dropbox Enterprise/Buiseness)
- LINK: https://dl.dropboxusercontent.com/scl/fi/76u7ysnz4c3mjqjh17ry1/DrevNET.zip?rlkey=y8acl7pg7clz8i7srn12gglg8&dl=0
- Step 1: Download and extract the .zip file
- Step 2: Run the premade shortcut (DrevNET.ink/DrevNET)
- Optional Step: You can copy the premade short of DrevNET.ink/DrevNET and paste it on your desktop for easier access.
